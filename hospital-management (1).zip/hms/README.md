# MediCare HMS (Angular 18)
Run: npm install, then npm start (http://localhost:4200)
Logins: admin/admin123 (all), doctor/doctor123 (own appointments, prescriptions, labs), reception/reception123 (patients, appointments, billing)
Build: npm run build -> dist/hospital-management/browser
Deploy: vercel.json (Vercel) or netlify.toml (Netlify).
