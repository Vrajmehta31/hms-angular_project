import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from './core/auth.service';

@Component({
  selector: 'app-root', standalone: true, imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
  @if (auth.user()) {
    <nav>
      <b>MediCare HMS</b>
      @for (l of links; track l) {
        @if (auth.can(l)) { <a [routerLink]="'/' + l" routerLinkActive="on">{{ l }}</a> }
      }
      <span class="sp"></span><span>{{ auth.user() }} ({{ auth.role() }})</span>
      <button (click)="out()">Logout</button>
    </nav>
  }
  <main><router-outlet /></main>`,
  styles: [`nav{display:flex;gap:14px;align-items:center;background:var(--d);color:#fff;padding:10px 20px;flex-wrap:wrap}
  nav a{color:#bfe;text-decoration:none;text-transform:capitalize}nav a.on{color:#fff;font-weight:700;border-bottom:2px solid #fff}
  .sp{flex:1}main{padding:20px;max-width:1100px;margin:auto}`]
})
export class AppComponent {
  auth = inject(AuthService); private r = inject(Router);
  links = ['dashboard', 'patients', 'doctors', 'appointments', 'prescriptions', 'labs', 'pharmacy', 'billing'];
  out() { this.auth.logout(); this.r.navigate(['/login']); }
}
