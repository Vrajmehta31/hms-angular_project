import { Injectable, signal, computed, inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export type Role = 'admin' | 'doctor' | 'reception';
const USERS: Record<string, { p: string; role: Role; doctorId?: number }> = {
  admin: { p: 'admin123', role: 'admin' },
  doctor: { p: 'doctor123', role: 'doctor', doctorId: 1 },
  reception: { p: 'reception123', role: 'reception' }
};
export const ACCESS: Record<string, Role[]> = {
  dashboard: ['admin', 'doctor', 'reception'], patients: ['admin', 'doctor', 'reception'],
  doctors: ['admin', 'reception'], appointments: ['admin', 'doctor', 'reception'],
  prescriptions: ['admin', 'doctor'], labs: ['admin', 'doctor'],
  pharmacy: ['admin'], billing: ['admin', 'reception']
};

@Injectable({ providedIn: 'root' })
export class AuthService {
  user = signal<string | null>(localStorage.getItem('hms.user'));
  role = computed<Role | null>(() => USERS[this.user() ?? '']?.role ?? null);
  doctorId = computed(() => USERS[this.user() ?? '']?.doctorId ?? null);
  login(u: string, p: string) {
    if (USERS[u] && USERS[u].p === p) { localStorage.setItem('hms.user', u); this.user.set(u); return true; }
    return false;
  }
  logout() { localStorage.removeItem('hms.user'); this.user.set(null); }
  can(path: string) { const r = this.role(); return !!r && (ACCESS[path] ?? []).includes(r); }
}
export const authGuard: CanActivateFn = (route) => {
  const a = inject(AuthService); const r = inject(Router);
  if (!a.user()) return r.createUrlTree(['/login']);
  return a.can(route.routeConfig?.path ?? '') ? true : r.createUrlTree(['/dashboard']);
};
