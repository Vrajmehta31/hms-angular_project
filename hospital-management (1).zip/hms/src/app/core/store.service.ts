import { Injectable, signal, effect } from '@angular/core';
import { Patient, Doctor, Appointment, Bill, Prescription, Medicine, LabReport } from './models';

function persisted<T>(key: string, seed: T[]) {
  const raw = localStorage.getItem(key);
  const s = signal<T[]>(raw ? JSON.parse(raw) : seed);
  effect(() => localStorage.setItem(key, JSON.stringify(s())));
  return s;
}

@Injectable({ providedIn: 'root' })
export class StoreService {
  patients = persisted<Patient>('hms.patients', [
    { id: 1, name: 'Ravi Kumar', age: 45, gender: 'Male', phone: '9000000001', disease: 'Diabetes' },
    { id: 2, name: 'Anita Rao', age: 32, gender: 'Female', phone: '9000000002', disease: 'Migraine' }]);
  doctors = persisted<Doctor>('hms.doctors', [
    { id: 1, name: 'Dr. Meera Nair', specialty: 'Cardiology', available: true },
    { id: 2, name: 'Dr. Arjun Das', specialty: 'Neurology', available: true }]);
  appointments = persisted<Appointment>('hms.appts', [
    { id: 1, patientId: 1, doctorId: 1, date: '2026-10-05', status: 'Scheduled' }]);
  bills = persisted<Bill>('hms.bills2', [
    { id: 1, patientId: 1, amount: 2500, paid: false, date: '2026-10-01' },
    { id: 2, patientId: 2, amount: 1800, paid: true, date: '2026-09-12' },
    { id: 3, patientId: 1, amount: 3200, paid: true, date: '2026-08-20' }]);
  prescriptions = persisted<Prescription>('hms.rx', [
    { id: 1, patientId: 1, doctorId: 1, date: '2026-09-28', diagnosis: 'Type 2 diabetes review', medicines: 'Metformin 500mg twice daily' }]);
  medicines = persisted<Medicine>('hms.meds', [
    { id: 1, name: 'Paracetamol 500mg', stock: 120, min: 30, price: 2 },
    { id: 2, name: 'Metformin 500mg', stock: 12, min: 25, price: 3 }]);
  labs = persisted<LabReport>('hms.labs', [
    { id: 1, patientId: 1, test: 'HbA1c', result: '7.2 %', date: '2026-09-28' }]);

  nextId(list: { id: number }[]) { return list.length ? Math.max(...list.map(x => x.id)) + 1 : 1; }
  patientName(id: number) { return this.patients().find(p => p.id === id)?.name ?? '-'; }
  doctorName(id: number) { return this.doctors().find(d => d.id === id)?.name ?? '-'; }
}
