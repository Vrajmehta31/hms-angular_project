export interface Patient { id: number; name: string; age: number; gender: string; phone: string; disease: string; }
export interface Doctor { id: number; name: string; specialty: string; available: boolean; }
export interface Appointment { id: number; patientId: number; doctorId: number; date: string; status: 'Scheduled' | 'Completed' | 'Cancelled'; }
export interface Bill { id: number; patientId: number; amount: number; paid: boolean; date: string; }
export interface Prescription { id: number; patientId: number; doctorId: number; date: string; diagnosis: string; medicines: string; }
export interface Medicine { id: number; name: string; stock: number; min: number; price: number; }
export interface LabReport { id: number; patientId: number; test: string; result: string; date: string; }
