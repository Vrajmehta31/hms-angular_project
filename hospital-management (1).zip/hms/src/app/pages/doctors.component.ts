import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-doctors', standalone: true, imports: [FormsModule],
  template: `<h2>Doctors</h2>
  <div class="card"><input [(ngModel)]="name" placeholder="Doctor name" /><input [(ngModel)]="spec" placeholder="Specialty" />
    <button (click)="add()">Add doctor</button></div>
  <div class="card"><table><tr><th>Name</th><th>Specialty</th><th>Status</th><th></th></tr>
  @for (d of s.doctors(); track d.id) {
    <tr><td>{{ d.name }}</td><td>{{ d.specialty }}</td><td><span class="tag">{{ d.available ? 'Available' : 'On leave' }}</span></td>
    <td><button (click)="toggle(d.id)">Toggle</button> <button class="del" (click)="remove(d.id)">Delete</button></td></tr>
  }</table></div>`
})
export class DoctorsComponent {
  s = inject(StoreService); name = ''; spec = '';
  add() { if (!this.name.trim()) return; this.s.doctors.update(l => [...l, { id: this.s.nextId(l), name: this.name, specialty: this.spec, available: true }]); this.name = this.spec = ''; }
  toggle(id: number) { this.s.doctors.update(l => l.map(d => d.id === id ? { ...d, available: !d.available } : d)); }
  remove(id: number) { this.s.doctors.update(l => l.filter(d => d.id !== id)); }
}
