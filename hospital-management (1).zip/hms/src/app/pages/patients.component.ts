import { Component, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-patients', standalone: true, imports: [FormsModule],
  template: `<h2>Patients</h2>
  <div class="card">
    <input [(ngModel)]="f.name" placeholder="Name" /><input [(ngModel)]="f.age" type="number" placeholder="Age" />
    <select [(ngModel)]="f.gender"><option>Male</option><option>Female</option><option>Other</option></select>
    <input [(ngModel)]="f.phone" placeholder="Phone" /><input [(ngModel)]="f.disease" placeholder="Condition" />
    <button (click)="save()">{{ editing() ? 'Update' : 'Add' }} patient</button>
  </div>
  <div class="card"><input [ngModel]="q()" (ngModelChange)="q.set($event)" placeholder="Search patients..." />
    <table><tr><th>Name</th><th>Age</th><th>Gender</th><th>Phone</th><th>Condition</th><th></th></tr>
    @for (p of rows(); track p.id) {
      <tr><td>{{ p.name }}</td><td>{{ p.age }}</td><td>{{ p.gender }}</td><td>{{ p.phone }}</td><td>{{ p.disease }}</td>
      <td><button (click)="edit(p.id)">Edit</button> <button class="del" (click)="remove(p.id)">Delete</button></td></tr>
    }</table></div>`
})
export class PatientsComponent {
  s = inject(StoreService);
  q = signal(''); editing = signal<number | null>(null);
  f = { name: '', age: 0, gender: 'Male', phone: '', disease: '' };
  rows = computed(() => this.s.patients().filter(p => (p.name + p.disease).toLowerCase().includes(this.q().toLowerCase())));
  save() {
    if (!this.f.name.trim()) return;
    const id = this.editing();
    if (id) this.s.patients.update(l => l.map(p => p.id === id ? { ...this.f, id } : p));
    else this.s.patients.update(l => [...l, { ...this.f, id: this.s.nextId(l) }]);
    this.editing.set(null); this.f = { name: '', age: 0, gender: 'Male', phone: '', disease: '' };
  }
  edit(id: number) { const p = this.s.patients().find(x => x.id === id)!; this.f = { ...p }; this.editing.set(id); }
  remove(id: number) { this.s.patients.update(l => l.filter(p => p.id !== id)); }
}
