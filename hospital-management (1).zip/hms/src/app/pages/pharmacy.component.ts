import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-pharmacy', standalone: true, imports: [FormsModule],
  template: `<h2>Pharmacy Inventory</h2>
  <div class="card">
    <input [(ngModel)]="name" placeholder="Medicine" /><input [(ngModel)]="stock" type="number" placeholder="Stock" />
    <input [(ngModel)]="min" type="number" placeholder="Min level" /><input [(ngModel)]="price" type="number" placeholder="Price" />
    <button (click)="add()">Add medicine</button></div>
  <div class="card"><table><tr><th>Medicine</th><th>Stock</th><th>Min</th><th>Price</th><th>Status</th><th></th></tr>
  @for (m of s.medicines(); track m.id) {
    <tr [style.background]="m.stock < m.min ? '#fdecea' : ''"><td>{{ m.name }}</td><td>{{ m.stock }}</td><td>{{ m.min }}</td><td>₹{{ m.price }}</td>
    <td><span class="tag">{{ m.stock < m.min ? 'LOW STOCK' : 'OK' }}</span></td>
    <td><button (click)="adj(m.id, 10)">+10</button> <button (click)="adj(m.id, -10)">-10</button> <button class="del" (click)="remove(m.id)">Delete</button></td></tr> }</table></div>`
})
export class PharmacyComponent {
  s = inject(StoreService); name = ''; stock = 0; min = 10; price = 0;
  add() { if (!this.name.trim()) return; this.s.medicines.update(l => [...l, { id: this.s.nextId(l), name: this.name, stock: this.stock, min: this.min, price: this.price }]); this.name = ''; this.stock = 0; }
  adj(id: number, n: number) { this.s.medicines.update(l => l.map(m => m.id === id ? { ...m, stock: Math.max(0, m.stock + n) } : m)); }
  remove(id: number) { this.s.medicines.update(l => l.filter(m => m.id !== id)); }
}
