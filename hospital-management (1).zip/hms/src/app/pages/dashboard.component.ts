import { Component, inject, computed } from '@angular/core';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-dashboard', standalone: true,
  template: `<h2>Dashboard</h2>
  <div class="grid">
    <div class="card stat"><b>{{ s.patients().length }}</b>Patients</div>
    <div class="card stat"><b>{{ s.doctors().length }}</b>Doctors</div>
    <div class="card stat"><b>{{ upcoming() }}</b>Upcoming appointments</div>
    <div class="card stat"><b>₹{{ revenue() }}</b>Revenue collected</div>
    <div class="card stat"><b>₹{{ pending() }}</b>Pending dues</div>
    <div class="card stat"><b>{{ lowStock() }}</b>Low-stock medicines</div>
  </div>
  <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(320px,1fr))">
    <div class="card"><h3>Monthly revenue</h3>
      @for (m of monthly(); track m.month) { <div>{{ m.month }} - ₹{{ m.total }}<div class="bar" [style.width.%]="m.pct"></div></div> }
    </div>
    <div class="card"><h3>Appointments by doctor</h3>
      @for (d of load(); track d.name) { <div>{{ d.name }} ({{ d.count }})<div class="bar" [style.width.%]="d.pct"></div></div> }
    </div>
    <div class="card"><h3>Patients by gender</h3>
      @for (g of gender(); track g.name) { <div>{{ g.name }} ({{ g.count }})<div class="bar" [style.width.%]="g.pct"></div></div> }
    </div>
  </div>`
})
export class DashboardComponent {
  s = inject(StoreService);
  upcoming = computed(() => this.s.appointments().filter(a => a.status === 'Scheduled').length);
  revenue = computed(() => this.s.bills().filter(b => b.paid).reduce((t, b) => t + b.amount, 0));
  pending = computed(() => this.s.bills().filter(b => !b.paid).reduce((t, b) => t + b.amount, 0));
  lowStock = computed(() => this.s.medicines().filter(m => m.stock < m.min).length);
  private scale(rows: { count: number }[]) { return Math.max(1, ...rows.map(r => r.count)); }
  load = computed(() => {
    const rows = this.s.doctors().map(d => ({ name: d.name, count: this.s.appointments().filter(a => a.doctorId === d.id).length }));
    const max = this.scale(rows); return rows.map(r => ({ ...r, pct: (r.count / max) * 100 }));
  });
  gender = computed(() => {
    const rows = ['Male', 'Female', 'Other'].map(g => ({ name: g, count: this.s.patients().filter(p => p.gender === g).length }));
    const max = this.scale(rows); return rows.map(r => ({ ...r, pct: (r.count / max) * 100 }));
  });
  monthly = computed(() => {
    const map: Record<string, number> = {};
    this.s.bills().filter(b => b.paid && b.date).forEach(b => { const m = b.date.slice(0, 7); map[m] = (map[m] ?? 0) + b.amount; });
    const rows = Object.keys(map).sort().map(month => ({ month, total: map[month] }));
    const max = Math.max(1, ...rows.map(r => r.total)); return rows.map(r => ({ ...r, pct: (r.total / max) * 100 }));
  });
}
