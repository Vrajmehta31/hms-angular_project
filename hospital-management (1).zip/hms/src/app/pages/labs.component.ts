import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StoreService } from '../core/store.service';

@Component({
  selector: 'app-labs', standalone: true, imports: [FormsModule],
  template: `<h2>Lab Reports</h2>
  <div class="card">
    <select [(ngModel)]="pid">@for (p of s.patients(); track p.id) { <option [ngValue]="p.id">{{ p.name }}</option> }</select>
    <input [(ngModel)]="test" placeholder="Test (e.g. CBC)" /><input [(ngModel)]="result" placeholder="Result" />
    <button (click)="add()">Add report</button></div>
  <div class="card"><table><tr><th>Date</th><th>Patient</th><th>Test</th><th>Result</th><th></th></tr>
  @for (l of s.labs(); track l.id) {
    <tr><td>{{ l.date }}</td><td>{{ s.patientName(l.patientId) }}</td><td>{{ l.test }}</td><td>{{ l.result }}</td>
    <td><button class="del" (click)="remove(l.id)">Delete</button></td></tr> }</table></div>`
})
export class LabsComponent {
  s = inject(StoreService); pid = 0; test = ''; result = '';
  add() {
    if (!this.pid || !this.test.trim()) return;
    this.s.labs.update(l => [...l, { id: this.s.nextId(l), patientId: this.pid, test: this.test, result: this.result, date: new Date().toISOString().slice(0, 10) }]);
    this.test = this.result = '';
  }
  remove(id: number) { this.s.labs.update(l => l.filter(x => x.id !== id)); }
}
