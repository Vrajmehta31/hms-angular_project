import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../core/auth.service';

@Component({
  selector: 'app-login', standalone: true, imports: [FormsModule],
  template: `<div class="card" style="max-width:340px;margin:80px auto">
    <h2>MediCare HMS Login</h2>
    <input [(ngModel)]="u" placeholder="Username" /><input [(ngModel)]="p" type="password" placeholder="Password" />
    <button (click)="go()">Sign in</button>
    @if (err) { <p style="color:#c0392b">Invalid credentials</p> }
    <small>Demo: admin / admin123, doctor / doctor123, reception / reception123</small></div>`
})
export class LoginComponent {
  private a = inject(AuthService); private r = inject(Router);
  u = ''; p = ''; err = false;
  go() { this.err = !this.a.login(this.u, this.p); if (!this.err) this.r.navigate(['/dashboard']); }
}
