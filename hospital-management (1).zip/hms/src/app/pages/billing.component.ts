import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StoreService } from '../core/store.service';
import { makePdf, download } from '../util/pdf';

@Component({
  selector: 'app-billing', standalone: true, imports: [FormsModule],
  template: `<h2>Billing</h2>
  <div class="card">
    <select [(ngModel)]="pid">@for (p of s.patients(); track p.id) { <option [ngValue]="p.id">{{ p.name }}</option> }</select>
    <input [(ngModel)]="amount" type="number" placeholder="Amount" /><button (click)="add()">Generate bill</button>
  </div>
  <div class="card"><table><tr><th>Bill #</th><th>Patient</th><th>Amount</th><th>Status</th><th></th></tr>
  @for (b of s.bills(); track b.id) {
    <tr><td>{{ b.id }}</td><td>{{ s.patientName(b.patientId) }}</td><td>₹{{ b.amount }}</td><td><span class="tag">{{ b.paid ? 'Paid' : 'Due' }}</span></td>
    <td>@if (!b.paid) { <button (click)="pay(b.id)">Mark paid</button> } <button (click)="pdf(b.id)">PDF invoice</button></td></tr>
  }</table></div>`
})
export class BillingComponent {
  s = inject(StoreService); pid = 0; amount = 0;
  add() { if (!this.pid || this.amount <= 0) return; this.s.bills.update(l => [...l, { id: this.s.nextId(l), patientId: this.pid, amount: this.amount, paid: false, date: new Date().toISOString().slice(0, 10) }]); this.amount = 0; }
  pay(id: number) { this.s.bills.update(l => l.map(b => b.id === id ? { ...b, paid: true } : b)); }
  pdf(id: number) {
    const b = this.s.bills().find(x => x.id === id)!;
    download(makePdf(['MediCare Hospital - INVOICE', '------------------------------', `Invoice no: ${b.id}`, `Date: ${b.date}`,
      `Patient: ${this.s.patientName(b.patientId)}`, `Amount: Rs. ${b.amount}`, `Status: ${b.paid ? 'PAID' : 'DUE'}`, '', 'Thank you. Get well soon.']), `invoice-${b.id}.pdf`);
  }
}
