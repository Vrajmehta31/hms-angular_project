import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StoreService } from '../core/store.service';
import { AuthService } from '../core/auth.service';

@Component({
  selector: 'app-appointments', standalone: true, imports: [FormsModule],
  template: `<h2>Appointments</h2>
  <div class="card">
    <select [(ngModel)]="pid">@for (p of s.patients(); track p.id) { <option [ngValue]="p.id">{{ p.name }}</option> }</select>
    <select [(ngModel)]="did">@for (d of avail(); track d.id) { <option [ngValue]="d.id">{{ d.name }} - {{ d.specialty }}</option> }</select>
    <input [(ngModel)]="date" type="date" /><button (click)="book()">Book</button>
    @if (msg) { <p style="color:#c0392b">{{ msg }}</p> }
  </div>
  <div class="card"><table><tr><th>Patient</th><th>Doctor</th><th>Date</th><th>Status</th><th></th></tr>
  @for (a of rows(); track a.id) {
    <tr><td>{{ s.patientName(a.patientId) }}</td><td>{{ s.doctorName(a.doctorId) }}</td><td>{{ a.date }}</td><td><span class="tag">{{ a.status }}</span></td>
    <td><button (click)="set(a.id,'Completed')">Complete</button> <button class="del" (click)="set(a.id,'Cancelled')">Cancel</button></td></tr>
  }</table></div>`
})
export class AppointmentsComponent {
  s = inject(StoreService); private au = inject(AuthService); pid = 0; did = 0; date = ''; msg = '';
  rows() { const d = this.au.doctorId(); return d ? this.s.appointments().filter(a => a.doctorId === d) : this.s.appointments(); }
  avail() { return this.s.doctors().filter(d => d.available); }
  book() {
    const clash = this.s.appointments().some(a => a.doctorId === this.did && a.date === this.date && a.status === 'Scheduled');
    if (!this.pid || !this.did || !this.date) { this.msg = 'Select patient, doctor and date.'; return; }
    if (clash) { this.msg = 'Doctor already booked on this date.'; return; }
    this.msg = '';
    this.s.appointments.update(l => [...l, { id: this.s.nextId(l), patientId: this.pid, doctorId: this.did, date: this.date, status: 'Scheduled' }]);
  }
  set(id: number, status: 'Completed' | 'Cancelled') { this.s.appointments.update(l => l.map(a => a.id === id ? { ...a, status } : a)); }
}
