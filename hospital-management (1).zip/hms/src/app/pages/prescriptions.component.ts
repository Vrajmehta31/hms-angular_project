import { Component, inject, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StoreService } from '../core/store.service';
import { AuthService } from '../core/auth.service';

@Component({
  selector: 'app-prescriptions', standalone: true, imports: [FormsModule],
  template: `<h2>Prescriptions &amp; Medical History</h2>
  <div class="card">
    <select [(ngModel)]="f.patientId">@for (p of s.patients(); track p.id) { <option [ngValue]="p.id">{{ p.name }}</option> }</select>
    <select [(ngModel)]="f.doctorId">@for (d of s.doctors(); track d.id) { <option [ngValue]="d.id">{{ d.name }}</option> }</select>
    <input [(ngModel)]="f.diagnosis" placeholder="Diagnosis" /><input [(ngModel)]="f.medicines" placeholder="Medicines and dosage" />
    <button (click)="add()">Save prescription</button>
  </div>
  <div class="card"><b>Patient history: </b>
    <select [ngModel]="filter()" (ngModelChange)="filter.set($event)"><option [ngValue]="0">All patients</option>
      @for (p of s.patients(); track p.id) { <option [ngValue]="p.id">{{ p.name }}</option> }</select>
    <table><tr><th>Date</th><th>Patient</th><th>Doctor</th><th>Diagnosis</th><th>Medicines</th></tr>
    @for (r of rows(); track r.id) { <tr><td>{{ r.date }}</td><td>{{ s.patientName(r.patientId) }}</td><td>{{ s.doctorName(r.doctorId) }}</td><td>{{ r.diagnosis }}</td><td>{{ r.medicines }}</td></tr> }</table>
    @if (filter()) { <h4>Lab reports</h4>
      @for (l of labsOf(); track l.id) { <div>{{ l.date }} - {{ l.test }}: {{ l.result }}</div> }
      @empty { <div>No lab reports.</div> } }
  </div>`
})
export class PrescriptionsComponent {
  s = inject(StoreService); private au = inject(AuthService);
  filter = signal(0);
  f = { patientId: 0, doctorId: this.au.doctorId() ?? 0, diagnosis: '', medicines: '' };
  rows = computed(() => this.s.prescriptions().filter(r => !this.filter() || r.patientId === this.filter()));
  labsOf = computed(() => this.s.labs().filter(l => l.patientId === this.filter()));
  add() {
    if (!this.f.patientId || !this.f.doctorId || !this.f.diagnosis.trim()) return;
    this.s.prescriptions.update(l => [...l, { ...this.f, id: this.s.nextId(l), date: new Date().toISOString().slice(0, 10) }]);
    this.f = { ...this.f, diagnosis: '', medicines: '' };
  }
}
