import { Routes } from '@angular/router';
import { authGuard } from './core/auth.service';
export const routes: Routes = [
  { path: 'login', loadComponent: () => import('./pages/login.component').then(m => m.LoginComponent) },
  { path: 'dashboard', canActivate: [authGuard], loadComponent: () => import('./pages/dashboard.component').then(m => m.DashboardComponent) },
  { path: 'patients', canActivate: [authGuard], loadComponent: () => import('./pages/patients.component').then(m => m.PatientsComponent) },
  { path: 'doctors', canActivate: [authGuard], loadComponent: () => import('./pages/doctors.component').then(m => m.DoctorsComponent) },
  { path: 'appointments', canActivate: [authGuard], loadComponent: () => import('./pages/appointments.component').then(m => m.AppointmentsComponent) },
  { path: 'billing', canActivate: [authGuard], loadComponent: () => import('./pages/billing.component').then(m => m.BillingComponent) },
  { path: 'prescriptions', canActivate: [authGuard], loadComponent: () => import('./pages/prescriptions.component').then(m => m.PrescriptionsComponent) },
  { path: 'labs', canActivate: [authGuard], loadComponent: () => import('./pages/labs.component').then(m => m.LabsComponent) },
  { path: 'pharmacy', canActivate: [authGuard], loadComponent: () => import('./pages/pharmacy.component').then(m => m.PharmacyComponent) },
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
  { path: '**', redirectTo: 'dashboard' }
];
